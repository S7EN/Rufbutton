﻿#Requires -Version 5.1
trap {
    $msg = "FEHLER Zeile $($_.InvocationInfo.ScriptLineNumber): $($_.Exception.Message)`n$($_.ScriptStackTrace)"
    $msg | Out-File $script:LogFile -Force -Encoding UTF8
    [System.Windows.Forms.MessageBox]::Show($msg, "Flash Tool Fehler", 0, 16) | Out-Null
    continue
}
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$ScriptDir         = Split-Path -Parent $MyInvocation.MyCommand.Definition
$script:LogFile    = Join-Path $ScriptDir "flash_error.log"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$FW_REPO      = "S7EN/Rufbutton"
$FW_API       = "https://api.github.com/repos/$FW_REPO/releases/latest"
$ESPTOOL_API  = "https://api.github.com/repos/espressif/esptool/releases/latest"

# Hardware-Parameter (ESP32-S3, 8 MB QIO 80MHz) --------------------------------
$CHIP         = "esp32s3"
$BAUD         = "921600"

# ---------- esptool finden ---------------------------------------------------
function Get-EsptoolPath {
    $local = Join-Path $ScriptDir "esptool.exe"
    if (Test-Path $local) { return $local }
    $base = "$env:LOCALAPPDATA\Arduino15\packages\esp32\tools\esptool_py"
    if (Test-Path $base) {
        $exe = Get-ChildItem "$base\*\esptool.exe" -ErrorAction SilentlyContinue |
               Sort-Object Name -Descending | Select-Object -First 1
        if ($exe) { return $exe.FullName }
    }
    foreach ($n in 'esptool','esptool.exe') {
        $c = Get-Command $n -ErrorAction SilentlyContinue
        if ($c) { return $c.Source }
    }
    return $null
}

# ---------- Download-Hilfe ---------------------------------------------------
function Download-WithProgress($url, $dest, [scriptblock]$logFn) {
    & $logFn "  Verbinde..." $script:Cy
    [System.Windows.Forms.Application]::DoEvents()
    Invoke-WebRequest -Uri $url -OutFile $dest -UseBasicParsing `
        -Headers @{'User-Agent'='Rufbutton-Flash-Tool/2.0'} -ErrorAction Stop
}

# ---------- esptool herunterladen --------------------------------------------
function Download-Esptool([scriptblock]$logFn) {
    try {
        & $logFn "Suche esptool auf GitHub..." $null
        [System.Windows.Forms.Application]::DoEvents()
        $rel   = Invoke-RestMethod -Uri $ESPTOOL_API -UseBasicParsing -ErrorAction Stop
        $asset = $rel.assets | Where-Object { $_.name -match 'win64\.zip$' } | Select-Object -First 1
        if (-not $asset) { & $logFn "Kein win64-Asset gefunden!" $script:Cr; return $false }
        $zipPath = Join-Path $env:TEMP $asset.name
        & $logFn "Lade esptool $($rel.tag_name) ($([math]::Round($asset.size/1MB,1)) MB)..." $null
        Download-WithProgress $asset.browser_download_url $zipPath $logFn
        & $logFn "Entpacke ZIP..." $null
        [System.Windows.Forms.Application]::DoEvents()
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $zip   = [System.IO.Compression.ZipFile]::OpenRead($zipPath)
        $entry = $zip.Entries | Where-Object { $_.Name -eq 'esptool.exe' } | Select-Object -First 1
        if (-not $entry) { $zip.Dispose(); & $logFn "esptool.exe nicht im ZIP!" $script:Cr; return $false }
        [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, (Join-Path $ScriptDir "esptool.exe"), $true)
        $zip.Dispose()
        Remove-Item $zipPath -ErrorAction SilentlyContinue
        & $logFn "esptool $($rel.tag_name) bereit." $script:Cg
        return $true
    } catch { & $logFn "esptool-Download fehlgeschlagen: $_" $script:Cr; return $false }
}

# ---------- Firmware herunterladen (merged.bin = alles in einem) -------------
function Get-FirmwareRelease {
    try { return Invoke-RestMethod -Uri $FW_API -UseBasicParsing -ErrorAction Stop }
    catch { return $null }
}

function Download-AllFirmware($release, $fullFlash, [scriptblock]$logFn) {
    try {
        $bins = $release.assets | Where-Object { $_.name -match '\.bin$' }
        if ($fullFlash) {
            $asset = $bins | Where-Object { $_.name -match 'merged' } | Select-Object -First 1
            if (-not $asset) { & $logFn "Kein merged.bin im Release $($release.tag_name)!" $script:Cr; return $null }
        } else {
            $asset = $bins | Where-Object { $_.name -notmatch 'merged|bootloader|partition' } | Select-Object -First 1
            if (-not $asset) { & $logFn "Kein App-Binary im Release $($release.tag_name)!" $script:Cr; return $null }
        }
        $dst = Join-Path $env:TEMP $asset.name
        $sizeStr = if ($asset.size -ge 1MB) { "$([math]::Round($asset.size/1MB,1)) MB" } else { "$([math]::Round($asset.size/1KB,0)) KB" }
        & $logFn "Lade $($asset.name) ($sizeStr)..." $null
        Download-WithProgress $asset.browser_download_url $dst $logFn
        & $logFn "Download abgeschlossen." $script:Cg
        return $dst
    } catch { & $logFn "Download fehlgeschlagen: $_" $script:Cr; return $null }
}

function Get-ComPorts { return [System.IO.Ports.SerialPort]::GetPortNames() | Sort-Object }

# ---------- Farben -----------------------------------------------------------
$Cbg  = [System.Drawing.Color]::FromArgb(28,  28,  28)
$Cbg2 = [System.Drawing.Color]::FromArgb(45,  45,  45)
$Cacc = [System.Drawing.Color]::FromArgb(0,  120, 215)
$Cfg  = [System.Drawing.Color]::White
$Cfgd = [System.Drawing.Color]::FromArgb(180, 180, 180)
$script:Cg   = [System.Drawing.Color]::FromArgb(80,  200, 120)
$script:Cr   = [System.Drawing.Color]::FromArgb(220, 80,  80)
$script:Cy   = [System.Drawing.Color]::FromArgb(255, 200, 80)

function New-Lbl($text, $x, $y, $w=90) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $text; $l.AutoSize = $false
    $l.Location = [System.Drawing.Point]::new($x,$y); $l.Size = [System.Drawing.Size]::new($w,22)
    $l.ForeColor = $Cfgd; $l.BackColor = $Cbg; $l.TextAlign = "MiddleLeft"; $l
}
function New-Cbo($x,$y,$w) {
    $c = New-Object System.Windows.Forms.ComboBox
    $c.Location = [System.Drawing.Point]::new($x,$y); $c.Size = [System.Drawing.Size]::new($w,22)
    $c.BackColor = $Cbg2; $c.ForeColor = $Cfg; $c.FlatStyle = "Flat"; $c.DropDownStyle = "DropDownList"; $c
}
function New-Btn($text,$x,$y,$w,$h=28) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $text; $b.Location = [System.Drawing.Point]::new($x,$y); $b.Size = [System.Drawing.Size]::new($w,$h)
    $b.BackColor = $Cbg2; $b.ForeColor = $Cfg; $b.FlatStyle = "Flat"
    $b.FlatAppearance.BorderColor = $Cacc; $b.Cursor = [System.Windows.Forms.Cursors]::Hand; $b
}

# ---------- Form -------------------------------------------------------------
[System.Windows.Forms.Application]::EnableVisualStyles()
[System.Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false)
$form = New-Object System.Windows.Forms.Form
$form.Text = "Rufbutton Flash Tool"; $form.ClientSize = [System.Drawing.Size]::new(520,560)
$form.StartPosition = "CenterScreen"; $form.FormBorderStyle = "FixedSingle"
$form.MaximizeBox = $false; $form.BackColor = $Cbg; $form.ForeColor = $Cfg
$form.TopMost = $true
$form.Font = New-Object System.Drawing.Font("Segoe UI",9)

# -- Firmware-Zeile ----------------------------------------------------------
$form.Controls.Add((New-Lbl "Firmware:" 16 18 90))
$lblVer = New-Object System.Windows.Forms.Label
$lblVer.Text = "(klicke Aktualisieren)"; $lblVer.Location = [System.Drawing.Point]::new(110,16)
$lblVer.Size = [System.Drawing.Size]::new(240,22); $lblVer.ForeColor = $script:Cy
$lblVer.BackColor = $Cbg; $lblVer.TextAlign = "MiddleLeft"; $form.Controls.Add($lblVer)

$script:_latestRelease = $null
$checkFw = {
    $lblVer.ForeColor = $script:Cy; $lblVer.Text = "Prüfe..."
    $r = Get-FirmwareRelease
    if ($r) { $script:_latestRelease = $r; $lblVer.Text = "Neueste: $($r.tag_name)"; $lblVer.ForeColor = $script:Cg }
    else    { $lblVer.Text = "Offline / kein Release gefunden"; $lblVer.ForeColor = $script:Cr }
}
$btnChk = New-Btn "Aktualisieren" 358 16 145
$btnChk.Add_Click({ try { & $checkFw } catch { $lblVer.Text = "Fehler: $_"; $lblVer.ForeColor = $script:Cr } })
$form.Controls.Add($btnChk)

# -- COM-Port -----------------------------------------------------------------
$form.Controls.Add((New-Lbl "COM-Port:" 16 58 90))
$cbPort = New-Cbo 110 56 150; $form.Controls.Add($cbPort)
$btnRef = New-Btn "Aktualisieren" 268 56 120
$refPorts = {
    $cbPort.Items.Clear()
    foreach ($p in (Get-ComPorts)) { $null = $cbPort.Items.Add($p) }
    if ($cbPort.Items.Count -gt 0) { $cbPort.SelectedIndex = $cbPort.Items.Count - 1 }
}
$btnRef.Add_Click($refPorts); $form.Controls.Add($btnRef)
& $refPorts

# -- Erase-Checkbox ----------------------------------------------------------
$chkErase = New-Object System.Windows.Forms.CheckBox
$chkErase.Text = "Komplett-Flash: Alles löschen + Bootloader neu schreiben (Einstellungen gehen verloren)"
$chkErase.Location = [System.Drawing.Point]::new(16,96); $chkErase.Size = [System.Drawing.Size]::new(488,22)
$chkErase.ForeColor = $script:Cy; $chkErase.BackColor = $Cbg; $chkErase.Checked = $false
$form.Controls.Add($chkErase)

# -- Flash-Button -------------------------------------------------------------
$btnFlash = New-Btn ">> FLASHEN <<" 16 132 488 46
$btnFlash.Font = New-Object System.Drawing.Font("Segoe UI",13,[System.Drawing.FontStyle]::Bold)
$btnFlash.BackColor = $Cacc; $btnFlash.FlatAppearance.BorderColor = $Cacc
$form.Controls.Add($btnFlash)

# -- Fortschrittsbalken -------------------------------------------------------
$pgb = New-Object System.Windows.Forms.ProgressBar
$pgb.Location = [System.Drawing.Point]::new(16,188); $pgb.Size = [System.Drawing.Size]::new(488,18)
$pgb.Minimum = 0; $pgb.Maximum = 100; $pgb.Value = 0; $pgb.Style = "Continuous"
$pgb.BackColor = $Cbg2; $pgb.ForeColor = $Cacc
$form.Controls.Add($pgb)

# -- Log ----------------------------------------------------------------------
$rtb = New-Object System.Windows.Forms.RichTextBox
$rtb.Location = [System.Drawing.Point]::new(16,216); $rtb.Size = [System.Drawing.Size]::new(488,328)
$rtb.BackColor = [System.Drawing.Color]::FromArgb(16,16,16); $rtb.ForeColor = $Cfgd
$rtb.Font = New-Object System.Drawing.Font("Consolas",9)
$rtb.ReadOnly = $true; $rtb.BorderStyle = "None"; $rtb.ScrollBars = "Vertical"
$form.Controls.Add($rtb)

function Log($line,$col=$null) {
    $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionLength = 0
    $rtb.SelectionColor = if ($col) { $col } else { $Cfgd }
    $rtb.AppendText("$line`n"); $rtb.ScrollToCaret()
    [System.Windows.Forms.Application]::DoEvents()
}

# ---------- esptool ausführen und Ausgabe streamen --------------------------
function Run-Esptool($esptool, $arguments, $pgbBase, $pgbRange) {
    $tmpLog = Join-Path $env:TEMP "esptool_log.txt"
    [System.IO.File]::WriteAllText($tmpLog, "")
    $script:_lastPos = 0
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName  = "cmd.exe"
    $psi.Arguments = "/c `"`"$esptool`" $arguments >> `"$tmpLog`" 2>&1`""
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow  = $true
    $proc = [System.Diagnostics.Process]::Start($psi)
    $timer = New-Object System.Windows.Forms.Timer
    $timer.Interval = 300
    $timer.Add_Tick({
        try {
            $fs = [System.IO.File]::Open($tmpLog, 'Open', 'Read', 'ReadWrite')
            $fs.Seek($script:_lastPos, 'Begin') | Out-Null
            $reader = New-Object System.IO.StreamReader($fs)
            $chunk = $reader.ReadToEnd()
            $script:_lastPos = $fs.Position
            $reader.Dispose(); $fs.Dispose()
            foreach ($line in ($chunk -split '[\r\n]+')) {
                $line = $line.Trim(); if (-not $line) { continue }
                if ($line -match '\((\d+)\s*%\)') {
                    $pct = [int]$Matches[1]
                    $abs = [int]($pgbBase + $pct * $pgbRange / 100)
                    if ($abs -gt $pgb.Value) { $pgb.Value = $abs }
                }
                $c = if     ($line -match '(?i)error|fail|exception') { $script:Cr }
                     elseif ($line -match '(?i)done|success|verif|leaving|Hash') { $script:Cg }
                     elseif ($line -match '%|Connecting|Compres|Wrote|Eras|chip|Stub|Baud|Flash') { $script:Cy }
                     else { $null }
                Log $line $c
            }
        } catch {}
    })
    $timer.Start()
    while (-not $proc.WaitForExit(200)) { [System.Windows.Forms.Application]::DoEvents() }
    $timer.Stop()
    Start-Sleep -Milliseconds 400
    $remaining = [System.IO.File]::ReadAllText($tmpLog)
    $rest = $remaining.Substring([Math]::Min($script:_lastPos, $remaining.Length))
    foreach ($line in ($rest -split '[\r\n]+')) {
        $line = $line.Trim(); if (-not $line) { continue }
        $c = if ($line -match '(?i)error|fail') { $script:Cr } elseif ($line -match '(?i)done|success|Hash') { $script:Cg } else { $null }
        Log $line $c
    }
    return $proc.ExitCode
}

# ---------- Flash-Logik ------------------------------------------------------
$btnFlash.Add_Click({
  try {
    if (-not $cbPort.SelectedItem) {
        [void][System.Windows.Forms.MessageBox]::Show("Bitte einen COM-Port auswählen!","Fehler",
            [System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error)
        return
    }
    $btnFlash.Enabled = $false; $rtb.Clear(); $pgb.Value = 0
    Log "========================================" $Cacc
    Log "   Rufbutton Flash Tool" $Cacc
    Log "========================================" $Cacc

    # 1. esptool sicherstellen
    $esptool = Get-EsptoolPath
    if (-not $esptool) {
        $btnFlash.Text = "Lade esptool..."
        Log "esptool nicht gefunden - lade von GitHub..." $script:Cy
        $ok = Download-Esptool -logFn { param($l,$c) Log $l $c }
        if (-not $ok) { $btnFlash.Enabled = $true; $btnFlash.Text = ">> FLASHEN <<"; return }
        $esptool = Join-Path $ScriptDir "esptool.exe"
    } else { Log "esptool: gefunden" $script:Cg }

    # 2. Alle Firmware-Binaries herunterladen (Bootloader + Partitionstabelle + App)
    $btnFlash.Text = "Lade Firmware..."
    Log "Lade Firmware von GitHub ($FW_REPO)..." $script:Cy
    $rel = if ($script:_latestRelease) { $script:_latestRelease } else { Get-FirmwareRelease }
    if (-not $rel) {
        Log "" $null
        Log "  FEHLER: GitHub nicht erreichbar!" $script:Cr
        $btnFlash.Enabled = $true; $btnFlash.Text = ">> FLASHEN <<"; return
    }
    $fullFlash = $chkErase.Checked
    $fw = Download-AllFirmware $rel $fullFlash -logFn { param($l,$c) Log $l $c }
    if (-not $fw) { $btnFlash.Enabled = $true; $btnFlash.Text = ">> FLASHEN <<"; return }

    $port = $cbPort.SelectedItem.ToString()
    Log "----------------------------------------"
    Log "Port : $port  |  Chip: $CHIP  |  Baud: $BAUD"
    Log "----------------------------------------"

    # 3. Kompletter Erase + merged.bin ODER nur App-Update
    $pgbStart = 0
    if ($fullFlash) {
        $btnFlash.Text = "Lösche Flash..."
        Log "Lösche kompletten Flash-Speicher..." $script:Cy
        $eraseArgs = "--chip $CHIP --port `"$port`" --baud $BAUD --before default-reset --after no-reset erase-flash"
        $exit = Run-Esptool $esptool $eraseArgs 0 10
        if ($exit -ne 0) {
            Log "Erase fehlgeschlagen (Exit: $exit)" $script:Cr
            $btnFlash.Enabled = $true; $btnFlash.Text = ">> FLASHEN <<"; return
        }
        Log "Erase abgeschlossen." $script:Cg
        $pgbStart = 10
    }

    # 4. Flashen
    $btnFlash.Text = "Flashe..."
    if ($fullFlash) {
        $flashArgs = "--chip $CHIP --port `"$port`" --baud $BAUD --before default-reset --after hard-reset " +
                     "write-flash -z 0x0 `"$fw`""
        Log "Schreibe merged.bin @ 0x0 (Bootloader + Partitionstabelle + Firmware)" $script:Cy
    } else {
        $flashArgs = "--chip $CHIP --port `"$port`" --baud $BAUD --before default-reset --after hard-reset " +
                     "write-flash -z 0x10000 `"$fw`""
        Log "Schreibe App-Binary @ 0x10000 (Einstellungen bleiben erhalten)" $script:Cy
    }
    $exit = Run-Esptool $esptool $flashArgs $pgbStart (100 - $pgbStart)
    Log "----------------------------------------"
    if ($exit -eq 0) { $pgb.Value = 100; Log "  Flash erfolgreich! Gerät startet neu." $script:Cg }
    else             { Log "  fehlgeschlagen (Exit: $exit)" $script:Cr }
  } catch {
    try { Log "Unerwarteter Fehler: $_" $script:Cr } catch {}
  }
  $btnFlash.Enabled = $true; $btnFlash.Text = ">> FLASHEN <<"
})

# ---------- Formular starten -----------------------------------------------
$script:_initTimer = New-Object System.Windows.Forms.Timer
$script:_initTimer.Interval = 500
$script:_initTimer.Add_Tick({
    $script:_initTimer.Stop()
    try { & $checkFw } catch { $lblVer.Text = "Fehler: $_"; $lblVer.ForeColor = $script:Cr }
})
$form.Add_Shown({ $lblVer.Text = "Prüfe GitHub..."; $script:_initTimer.Start() })
[System.Windows.Forms.Application]::Run($form)