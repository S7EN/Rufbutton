@echo off
powershell.exe -ExecutionPolicy Bypass -File "%~dp0Flash.ps1"
